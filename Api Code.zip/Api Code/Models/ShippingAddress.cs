﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementSystem.Models
{
    public class Address
    {
        public string RecipientName { get; set; }
        public string PhoneNumber { get; set; }
        public  int Pincode { get; set; }
        public string HouseNo { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
    }
}