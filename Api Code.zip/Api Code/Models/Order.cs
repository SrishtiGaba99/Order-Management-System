﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementSystem.Models
{
    public enum OrderStatus
    {
        Placed,Approved, Cancelled, InDelivery, Completed
    }
    public class OrderItem
    {
        public Product product { get; set; }
        public int quantity { get; set; }
        public int OrderId { get; set; }
    }
    public class Order
    {
        public int OrderId { get; set; }
        public ApplicationUser buyer { get; set; }
        public Address shippingAddress { get; set; }
        public string status { get; set; }
        public List<OrderItem> cart { get; set; }
        public DateTime OrderingTime { get; set; }
    }
}