﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Configuration;
using OrderManagementSystem.Models;
using System.Data.Common;
using System.Data;
using System.Web.Mvc;

namespace OrderManagementSystem.DataLayer
{
    public class OrderDataAccessLayer
    {
        SqlDatabase _dbConnectionString;
        int CommandTimeOutValue = 3000;

        public OrderDataAccessLayer(){
            _dbConnectionString = new SqlDatabase(ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString.ToString());
          }
        public List<Order> GetOrders(int UserId)
        {
            try
            {
                List<Order> LstModelObj = new List<Order>();
                List<OrderItem> CartItems = new List<OrderItem>();
                DbCommand CommandObj = _dbConnectionString.GetStoredProcCommand("DBO.GET_ORDERS");
                _dbConnectionString.AddInParameter(CommandObj, "@USER", DbType.Int32, UserId);
                CommandObj.CommandTimeout = CommandTimeOutValue;
                DataSet ds = new DataSet();

                ds = _dbConnectionString.ExecuteDataSet(CommandObj);
                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        
                        foreach (DataRow dr in dt.Rows)
                        {
                            Order ModelObj = new Order();
                            ModelObj.OrderId= Convert.ToInt32(dr["ORDER_ID"].ToString());
                            ModelObj.status = dr["ORDER_STATUS"].ToString();
                            ApplicationUser user = new ApplicationUser();
                                user.UseriD = Convert.ToInt32(dr["BUYER_ID"].ToString());
                                user.UserName = dr["BUYER_NAME"].ToString();
                            ModelObj.buyer = user;
                            Address a = new Address();
                                a.RecipientName= dr["NAME"].ToString();
                                a.HouseNo= dr["H_NO"].ToString();
                                a.City = dr["CITY"].ToString();
                                a.Street = dr["STREET"].ToString();
                                a.State = dr["STATE"].ToString();
                            ModelObj.shippingAddress = a;                           
                            LstModelObj.Add(ModelObj);
                        }
                        DataTable dt2 = ds.Tables[1];
                        if (dt2!=null && dt2.Rows.Count > 0)
                        {
                            foreach(DataRow dr in dt2.Rows)
                            {
                                OrderItem oi = new OrderItem();
                                oi.OrderId= Convert.ToInt32(dr["ORDER_ID"].ToString());
                                oi.quantity= Convert.ToInt32(dr["QUANTITY"].ToString());
                                Product p = new Product();
                                p.Id= Convert.ToInt32(dr["PRODUCT_ID"].ToString());
                                p.Name = (dr["PRODUCT_NAME"].ToString());
                                oi.product = p;
                                CartItems.Add(oi);
                            }
                        }
                    }

                }
                foreach(var Obj in LstModelObj)
                {
                    Obj.cart = CartItems.Where(c => c.OrderId == Obj.OrderId).ToList();
                }
                return LstModelObj;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
        }

        public int DeleteOrder(int OrderId)
        {
            try
            {
                int result = 0;
                DbCommand CommandObj = _dbConnectionString.GetStoredProcCommand("DBO.DELETE_ORDER");
                _dbConnectionString.AddInParameter(CommandObj, "@ORDER_ID", DbType.Int32, OrderId);
                result = Convert.ToInt32(_dbConnectionString.ExecuteScalar(CommandObj));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
        }

        public int AddOrEditOrder(Order o,int UserId)
        {

            int result = 0;
            DataTable Tvp = CreateProductsTvp(o.cart);
            DbCommand CommandObj = _dbConnectionString.GetStoredProcCommand("[DBO].[PLACE_OR_MODFY_ORDER]");
            _dbConnectionString.AddInParameter(CommandObj, "@ORDER_ID", DbType.Int32, o.OrderId);
            _dbConnectionString.AddInParameter(CommandObj, "@PRODUCTS_TVP", SqlDbType.Structured, Tvp);
            _dbConnectionString.AddInParameter(CommandObj, "@USER", DbType.Int32, UserId);//asuming only buyer can add and modify
            _dbConnectionString.AddInParameter(CommandObj, "@H_NO", DbType.String, o.shippingAddress.HouseNo);
            _dbConnectionString.AddInParameter(CommandObj, "@STREET", DbType.String, o.shippingAddress.Street);
            _dbConnectionString.AddInParameter(CommandObj, "@CITY", DbType.String, o.shippingAddress.City);
            _dbConnectionString.AddInParameter(CommandObj, "@STATE", DbType.String, o.shippingAddress.State);
            _dbConnectionString.AddInParameter(CommandObj, "@PINCODE", DbType.Int32, o.shippingAddress.Pincode);
            _dbConnectionString.AddInParameter(CommandObj, "@RECIEVER_NAME", DbType.String, o.shippingAddress.RecipientName);
            _dbConnectionString.AddInParameter(CommandObj, "@RECIEVER_PHONE", DbType.Int32, o.shippingAddress.PhoneNumber);
            //NOT ADDING STATUS AS THAT SHOULD NOT BE EDITABLE OR COULD BE ADDED BY USER
            CommandObj.CommandTimeout = CommandTimeOutValue;
            result = Convert.ToInt32(_dbConnectionString.ExecuteNonQuery(CommandObj));
            return result;
        }
        public DataTable CreateProductsTvp(List<OrderItem> Oi)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("PRODUCT_ID", typeof(int));
            dt.Columns.Add("QUANTITY", typeof(int));

            foreach(OrderItem item in Oi)
            {
                DataRow dtr = dt.NewRow();
                dtr["PRODUCT_ID"] = item.product.Id;
                dtr["QUANTITY"] = item.quantity;
                dt.Rows.Add(dtr);
            }
            return dt;
        }
    }
}