﻿using Microsoft.AspNet.Identity;
using Microsoft.Identity.Client;
using OrderManagementSystem.DataLayer;
using OrderManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OrderManagementSystem.Controllers.Api
{
    public class OrdersController : ApiController
    {
        OrderDataAccessLayer DalObj;

        
        public OrdersController()
        {
            DalObj = new OrderDataAccessLayer();
        }

        [Authorize]
        public List<Order> GetOrders()
        {
            try
            {
                List<Order> result = new List<Order>();
                int UserId = Convert.ToInt32(User.Identity.GetUserId());
                result = DalObj.GetOrders(UserId);
                return result;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
            
        }

        [Authorize]
        [HttpPost]
        public int DeleteOrder(int OrderId)
        {
            try
            {
                return DalObj.DeleteOrder(OrderId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
        }
        [Authorize]
        [HttpPost]
        public int AddOrder(Order order)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return -1;
                }
                int UserId = Convert.ToInt32(User.Identity.GetUserId());
                return DalObj.AddOrEditOrder(order, UserId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
        }

        [Authorize]
        [HttpPut]
        public int EditOrder(Order order)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return -1;
                }
                int UserId = Convert.ToInt32(User.Identity.GetUserId());
                return DalObj.AddOrEditOrder(order, UserId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message.ToString(), ex.InnerException);
            }
        }
    }
}
